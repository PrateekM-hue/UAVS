package com.company.uavs.entity;

public enum TransactionStatus {
    NEW,
    ACTIVATED,
    VOIDED,
    FAILED,
    PENDING
}